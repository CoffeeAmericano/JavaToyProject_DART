package Page_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Button;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JEditorPane;
import javax.swing.JComboBox;
import java.awt.Choice;
import javax.swing.JRadioButton;
import java.awt.Label;
import java.awt.TextField;
import javax.swing.JProgressBar;
import java.awt.ScrollPane;
import java.awt.Color;
import java.awt.Canvas;
import java.awt.Checkbox;
import java.awt.List;
import java.awt.TextArea;
import java.awt.Scrollbar;
import java.awt.Font;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.Box;

public class TEST_2_1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TEST_2_1 frame = new TEST_2_1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TEST_2_1() {
		setTitle("\u2665Heart Dart\u2665");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 954, 584);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(680, 116, 242, 409);
		contentPane.add(panel);
		panel.setLayout(null);
		
		Label label_3 = new Label("\uACC4\uC0B0\uC2DD");
		label_3.setBounds(94, 181, 77, 25);
		panel.add(label_3);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(192, 192, 192));
		panel_1.setBounds(14, 116, 648, 409);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		Button EXPORT = new Button("EXPORT");
		EXPORT.setFont(new Font("Microsoft JhengHei", Font.PLAIN, 20));
		EXPORT.setBackground(new Color(255, 235, 205));
		EXPORT.setActionCommand("EXPORT");
		EXPORT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		EXPORT.setBounds(490, 326, 129, 59);
		panel_1.add(EXPORT);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.DARK_GRAY);
		panel_2.setBounds(14, 12, 908, 90);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\uC870\uAC74 \uAC80\uC0C9 :");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("����", Font.BOLD, 14));
		lblNewLabel.setBackground(new Color(0, 0, 0));
		lblNewLabel.setBounds(14, 32, 85, 40);
		panel_2.add(lblNewLabel);
		
		Choice choice = new Choice();
		choice.setBounds(101, 42, 125, 24);
		panel_2.add(choice);
		
		Choice choice_2 = new Choice();
		choice_2.setBounds(441, 42, 125, 24);
		panel_2.add(choice_2);
		
		Choice choice_3 = new Choice();
		choice_3.setBounds(582, 42, 125, 24);
		panel_2.add(choice_3);
		
		Label label = new Label("\uD68C\uC0AC\uBA85 / \uCF54\uB4DC");
		label.setFont(new Font("Dialog", Font.BOLD, 15));
		label.setForeground(Color.WHITE);
		label.setBounds(101, 11, 125, 25);
		panel_2.add(label);
		
		Label label_1 = new Label("\uB144\uB3C4");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("Dialog", Font.BOLD, 15));
		label_1.setBounds(245, 11, 77, 25);
		panel_2.add(label_1);
		
		Label label_2 = new Label("\uBCF4\uACE0\uC11C \uC885\uB958");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("Dialog", Font.BOLD, 15));
		label_2.setBounds(441, 11, 135, 25);
		panel_2.add(label_2);
		
		Label label_2_1 = new Label("\uD56D\uBAA9");
		label_2_1.setForeground(Color.WHITE);
		label_2_1.setFont(new Font("Dialog", Font.BOLD, 15));
		label_2_1.setBounds(582, 11, 125, 25);
		panel_2.add(label_2_1);
		
		Checkbox checkbox = new Checkbox("\uD45C");
		checkbox.setForeground(Color.WHITE);
		checkbox.setFont(new Font("Dialog", Font.BOLD, 15));
		checkbox.setBounds(713, 10, 71, 30);
		panel_2.add(checkbox);
		
		Checkbox checkbox_1 = new Checkbox("\uADF8\uB798\uD504");
		checkbox_1.setForeground(Color.WHITE);
		checkbox_1.setFont(new Font("Dialog", Font.BOLD, 15));
		checkbox_1.setBounds(713, 42, 71, 30);
		panel_2.add(checkbox_1);
		
		Choice choice_1 = new Choice();
		choice_1.setBounds(245, 42, 87, 24);
		panel_2.add(choice_1);
		
		Choice choice_1_1 = new Choice();
		choice_1_1.setBounds(338, 42, 85, 24);
		panel_2.add(choice_1_1);
		
		Label label_4 = new Label("\uBD84\uAE30");
		label_4.setFont(new Font("Dialog", Font.BOLD, 15));
		label_4.setForeground(Color.WHITE);
		label_4.setBounds(335, 11, 77, 25);
		panel_2.add(label_4);
		
		Button button = new Button("\uAC80\uC0C9");
		button.setForeground(new Color(255, 255, 255));
		button.setFont(new Font("Dialog", Font.BOLD, 20));
		button.setBackground(new Color(250, 128, 114));
		button.setBounds(790, 11, 108, 69);
		panel_2.add(button);
	}
}
