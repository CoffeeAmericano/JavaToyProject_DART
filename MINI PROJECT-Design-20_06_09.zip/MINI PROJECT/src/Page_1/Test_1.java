package Page_1;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.Choice;
import java.awt.Label;
import java.awt.TextField;
import java.awt.Button;
import java.awt.Font;
import java.awt.Canvas;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import javax.swing.JEditorPane;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.SwingConstants;

public class Test_1 extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test_1 frame = new Test_1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Test_1() {
		setTitle("\u2665Heart Dart\u2665");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1075, 622);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		Panel panel = new Panel();
		panel.setBackground(Color.DARK_GRAY);
		panel.setBounds(0, 0, 234, 575);
		contentPane.add(panel);
		panel.setLayout(null);
		
		Label label = new Label("\uD68C\uC0AC\uBA85");
		label.setFont(new Font("Constantia", Font.BOLD, 15));
		label.setForeground(new Color(255, 255, 255));
		label.setBounds(30, 140, 55, 25);
		panel.add(label);
		
		TextField textField = new TextField();
		textField.setBounds(101, 140, 103, 25);
		panel.add(textField);
		
		Button button = new Button("SEARCH");
		button.setForeground(new Color(139, 0, 0));
		button.setBackground(new Color(255, 99, 71));
		button.setFont(new Font("Dialog", Font.BOLD, 24));
		button.setBounds(52, 502, 139, 63);
		panel.add(button);
		
		Label label_1 = new Label("\uC885\uBAA9\uCF54\uB4DC");
		label_1.setFont(new Font("Dialog", Font.BOLD, 15));
		label_1.setForeground(new Color(255, 255, 255));
		label_1.setBounds(30, 202, 65, 25);
		panel.add(label_1);
		
		TextField textField_1 = new TextField();
		textField_1.setBounds(101, 202, 103, 25);
		panel.add(textField_1);
		
		Label label_1_1 = new Label("\uB144\uB3C4");
		label_1_1.setForeground(new Color(255, 255, 255));
		label_1_1.setFont(new Font("Dialog", Font.BOLD, 15));
		label_1_1.setBounds(40, 233, 33, 25);
		panel.add(label_1_1);
		
		Label label_1_2 = new Label("\uBD84\uAE30");
		label_1_2.setFont(new Font("Dialog", Font.BOLD, 15));
		label_1_2.setForeground(new Color(255, 255, 255));
		label_1_2.setBounds(40, 264, 33, 25);
		panel.add(label_1_2);
		
		Choice choice = new Choice();
		choice.setBounds(101, 234, 103, 24);
		panel.add(choice);
		
		Choice choice_1 = new Choice();
		choice_1.setBounds(101, 265, 103, 24);
		panel.add(choice_1);
		
		TextArea textArea = new TextArea();
		textArea.setBounds(30, 306, 175, 190);
		panel.add(textArea);
		
		Label label_1_2_1 = new Label("\uC5C5\uC885");
		label_1_2_1.setForeground(new Color(255, 255, 255));
		label_1_2_1.setFont(new Font("Dialog", Font.BOLD, 15));
		label_1_2_1.setBounds(40, 171, 33, 25);
		panel.add(label_1_2_1);
		
		TextField textField_1_1 = new TextField();
		textField_1_1.setBounds(101, 171, 103, 25);
		panel.add(textField_1_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(Test_1.class.getResource("/Page_1/heartTest2.png")));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("����", Font.BOLD, 30));
		lblNewLabel.setBounds(-60, 12, 264, 122);
		panel.add(lblNewLabel);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBounds(255, 28, 383, 327);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setIcon(new ImageIcon(Test_1.class.getResource("/Page_1/logo.png")));
		lblNewLabel_1.setBounds(26, 0, 331, 327);
		panel_1.add(lblNewLabel_1);
		
		Panel panel_1_1 = new Panel();
		panel_1_1.setBackground(new Color(192, 192, 192));
		panel_1_1.setBounds(664, 28, 372, 327);
		contentPane.add(panel_1_1);
		panel_1_1.setLayout(null);
		
		Panel panel_1_2 = new Panel();
		panel_1_2.setBounds(644, 491, 403, 84);
		contentPane.add(panel_1_2);
		panel_1_2.setLayout(null);
		
		Button button_1 = new Button("\uC8FC\uC11D");
		button_1.setFont(new Font("Georgia", Font.BOLD, 20));
		button_1.setForeground(new Color(255, 255, 255));
		button_1.setBackground(new Color(255, 99, 71));
		button_1.setBounds(74, 10, 112, 58);
		panel_1_2.add(button_1);
		
		Button button_1_1 = new Button("\uC120\uD0DD\uC870\uAC74\u25B7");
		button_1_1.setForeground(new Color(255, 255, 255));
		button_1_1.setFont(new Font("Dialog", Font.BOLD, 20));
		button_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		button_1_1.setBackground(new Color(255, 99, 71));
		button_1_1.setBounds(215, 10, 119, 58);
		panel_1_2.add(button_1_1);
		
		Panel panel_1_2_1 = new Panel();
		panel_1_2_1.setBackground(new Color(192, 192, 192));
		panel_1_2_1.setBounds(255, 375, 383, 176);
		contentPane.add(panel_1_2_1);
		panel_1_2_1.setLayout(null);
		
		Panel panel_2 = new Panel();
		panel_2.setBackground(new Color(192, 192, 192));
		panel_2.setBounds(664, 378, 372, 106);
		contentPane.add(panel_2);
	}
}
